Test data for the Dainvo language pack tests.
